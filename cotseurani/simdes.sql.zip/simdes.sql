-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 28, 2015 at 08:03 
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `simdes`
--

-- --------------------------------------------------------

--
-- Table structure for table `det_keluarga`
--

CREATE TABLE IF NOT EXISTS `det_keluarga` (
  `id_keluarga` varchar(20) NOT NULL,
  `no_ktp` varchar(20) NOT NULL,
  KEY `id_warga` (`no_ktp`,`id_keluarga`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `det_keluarga`
--

INSERT INTO `det_keluarga` (`id_keluarga`, `no_ktp`) VALUES
('90', '198988'),
('8999', '42434'),
('56', '5362772'),
('90909', '56644'),
('88888', '777788'),
('788', '7878');

-- --------------------------------------------------------

--
-- Table structure for table `kelahiran`
--

CREATE TABLE IF NOT EXISTS `kelahiran` (
  `id_kelahiran` int(5) NOT NULL AUTO_INCREMENT,
  `no_suratlahir` varchar(15) NOT NULL,
  `no_kk` varchar(15) NOT NULL,
  `anak` varchar(15) NOT NULL,
  `tgl` varchar(15) NOT NULL,
  PRIMARY KEY (`id_kelahiran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `kelahiran`
--


-- --------------------------------------------------------

--
-- Table structure for table `keluarga`
--

CREATE TABLE IF NOT EXISTS `keluarga` (
  `id_keluarga` varchar(20) NOT NULL,
  `kepala_keluarga` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `dusun` varchar(30) NOT NULL,
  `rt` varchar(2) DEFAULT NULL,
  `rw` varchar(2) DEFAULT NULL,
  `ekonomi` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_keluarga`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keluarga`
--

INSERT INTO `keluarga` (`id_keluarga`, `kepala_keluarga`, `alamat`, `dusun`, `rt`, `rw`, `ekonomi`) VALUES
('8999', 'Arul', 'cot seurani', 'Klagen', '01', '02', 'Sangat_Kaya'),
('90909', 'shaljan', 'cot seurani', 'Ngembung', '02', '03', 'Sangat_Kaya'),
('788', 'Azman Abdul Wahid', 'cot seurani', 'Cot', '01', '01', 'Kaya'),
('88888', 'Putri', 'cot seurani', 'Balee', '02', '02', 'Sangat_Kaya'),
('90', 'Rinda Renggali Putri', 'cot seurani', 'Balee', '01', '02', 'Kaya'),
('56', 'aidi safarah', 'cot seurani', 'Balee', '03', '03', 'Miskin');

--
-- Triggers `keluarga`
--
DROP TRIGGER IF EXISTS `hapus_detail_klg`;
DELIMITER //
CREATE TRIGGER `hapus_detail_klg` AFTER DELETE ON `keluarga`
 FOR EACH ROW begin

delete  from det_keluarga where det_keluarga.id_keluarga = old.id_keluarga;

end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kematian`
--

CREATE TABLE IF NOT EXISTS `kematian` (
  `id_kematian` int(5) NOT NULL AUTO_INCREMENT,
  `no_suratkematian` varchar(15) NOT NULL,
  `no_kk` varchar(15) NOT NULL,
  `tgl_meninggal` varchar(15) NOT NULL,
  `jam_meninggal` varchar(15) NOT NULL,
  `tempat_meninggal` varchar(30) NOT NULL,
  `sebab_meninggal` varchar(50) NOT NULL,
  PRIMARY KEY (`id_kematian`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `kematian`
--


-- --------------------------------------------------------

--
-- Table structure for table `mutasi_warga`
--

CREATE TABLE IF NOT EXISTS `mutasi_warga` (
  `id_mutasi` mediumint(9) NOT NULL AUTO_INCREMENT,
  `id_warga` varchar(20) NOT NULL,
  `jenis_mutasi` varchar(15) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_mutasi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mutasi_warga`
--


-- --------------------------------------------------------

--
-- Table structure for table `surat`
--

CREATE TABLE IF NOT EXISTS `surat` (
  `id_surat` int(8) NOT NULL AUTO_INCREMENT,
  `jenis_surat` varchar(4) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `nama_surat` varchar(50) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `isi_surat` text,
  `tanda_tangan` varchar(50) NOT NULL,
  `id_warga` varchar(20) NOT NULL,
  `nama_warga` varchar(50) NOT NULL,
  PRIMARY KEY (`id_surat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `surat`
--

INSERT INTO `surat` (`id_surat`, `jenis_surat`, `no_surat`, `nama_surat`, `tanggal`, `isi_surat`, `tanda_tangan`, `id_warga`, `nama_warga`) VALUES
(3, 'SK', '470/4/437.105.08/2015', 'Surat Keterangan ', '2015-06-28', '{"nama":"azman","t_lahir":"cs,  08-06-2015","j_kel":"Laki - laki","w_negara":"jn","pendidikan":"jl","agama":"Islam","pekerjaan":"jh","s_nikah":"belum_nikah","no_ktp":"7878","alamat":"hhj RT 01 RW 02 Dusun Klagen","ket":"eeh5tntntnjtntnh"}', '{"pejabat":"Munawar","nip":""}', '7878', 'azman');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_detail_warga`
--
CREATE TABLE IF NOT EXISTS `v_detail_warga` (
`id_keluarga` varchar(20)
,`no_ktp` varchar(20)
,`nama` varchar(50)
,`agama` varchar(20)
,`t_lahir` varchar(20)
,`tgl_lahir` varchar(10)
,`j_kel` varchar(11)
,`gol_darah` varchar(2)
,`w_negara` varchar(20)
,`pendidikan` varchar(10)
,`pekerjaan` varchar(30)
,`s_nikah` varchar(20)
,`alamat` text
,`rt` varchar(2)
,`rw` varchar(2)
,`dusun` varchar(30)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `v_mutasi_warga`
--
CREATE TABLE IF NOT EXISTS `v_mutasi_warga` (
`id_warga` varchar(20)
,`j_kel` enum('L','W')
,`jenis_mutasi` varchar(15)
,`periode` varchar(7)
,`keterangan` text
);
-- --------------------------------------------------------

--
-- Table structure for table `warga`
--

CREATE TABLE IF NOT EXISTS `warga` (
  `no_ktp` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `t_lahir` varchar(20) NOT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `j_kel` enum('L','W') NOT NULL,
  `gol_darah` varchar(2) NOT NULL,
  `w_negara` varchar(20) NOT NULL,
  `pendidikan` varchar(10) DEFAULT NULL,
  `pekerjaan` varchar(30) NOT NULL,
  `s_nikah` varchar(20) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`no_ktp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warga`
--

INSERT INTO `warga` (`no_ktp`, `nama`, `agama`, `t_lahir`, `tgl_lahir`, `j_kel`, `gol_darah`, `w_negara`, `pendidikan`, `pekerjaan`, `s_nikah`, `status`) VALUES
('7878', 'Azman Abdul Wahid', 'Islam', 'cs', '2015-06-08', 'L', 'O', 'jn', 'jl', 'jh', 'belum_nikah', '1'),
('98989', 'Habil', 'Islam', 'cs', '1998-04-07', 'L', 'AB', 'hbh', 'jn', 'jij', 'belum_nikah', '1'),
('198988', 'Rinda Renggali Putri', 'Islam', 'Takengon', '1997-03-15', 'W', 'A', 'Indonesia', 'Mahs', 'Mahasiswa', 'belum_nikah', '1'),
('878748', 'Azkia', 'Islam', 'leubu', '2015-06-17', 'L', 'AB', 'kjkjhj', 'jkj', 'kjk', 'belum_nikah', '1'),
('56644', 'shaljan', 'Islam', 'banda aceh', '2015-06-08', 'L', 'A', 'klklkl', 'jkj', 'jhj', 'belum_nikah', '1'),
('777788', 'Putri', 'Islam', 'jgug', '2015-06-11', 'W', 'O', 'klk', 'klkl', 'klk', 'belum_nikah', '1'),
('42434', 'Arul', 'Islam', 'hjhjk', '2015-06-15', 'L', 'B', 'jkjk', 'pop', 'pp', 'belum_nikah', '1'),
('65644', 'asyrafi', 'Islam', 'fgfg', '2015-06-25', 'L', 'O', 'lllk', 'jkj', 'rere', 'belum_nikah', '1'),
('5362772', 'aidi safarah', 'Islam', 'hghg', '2015-06-10', 'W', 'A', 'gg', 'gg', 'gg', 'belum_nikah', '1');

-- --------------------------------------------------------

--
-- Structure for view `v_detail_warga`
--
DROP TABLE IF EXISTS `v_detail_warga`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_detail_warga` AS select `a`.`id_keluarga` AS `id_keluarga`,`c`.`no_ktp` AS `no_ktp`,`c`.`nama` AS `nama`,`c`.`agama` AS `agama`,`c`.`t_lahir` AS `t_lahir`,date_format(`c`.`tgl_lahir`,'%d-%m-%Y') AS `tgl_lahir`,if((`c`.`j_kel` = 'L'),'Laki - laki','Wanita') AS `j_kel`,`c`.`gol_darah` AS `gol_darah`,`c`.`w_negara` AS `w_negara`,`c`.`pendidikan` AS `pendidikan`,`c`.`pekerjaan` AS `pekerjaan`,`c`.`s_nikah` AS `s_nikah`,`a`.`alamat` AS `alamat`,`a`.`rt` AS `rt`,`a`.`rw` AS `rw`,`a`.`dusun` AS `dusun` from ((`keluarga` `a` join `det_keluarga` `b`) join `warga` `c`) where ((`a`.`id_keluarga` = `b`.`id_keluarga`) and (`b`.`no_ktp` = `c`.`no_ktp`) and (`c`.`status` = '1'));

-- --------------------------------------------------------

--
-- Structure for view `v_mutasi_warga`
--
DROP TABLE IF EXISTS `v_mutasi_warga`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_mutasi_warga` AS select `mutasi_warga`.`id_warga` AS `id_warga`,`warga`.`j_kel` AS `j_kel`,`mutasi_warga`.`jenis_mutasi` AS `jenis_mutasi`,date_format(`mutasi_warga`.`tanggal`,'%m-%Y') AS `periode`,`mutasi_warga`.`keterangan` AS `keterangan` from (`mutasi_warga` join `warga` on((`warga`.`no_ktp` = `mutasi_warga`.`id_warga`)));
